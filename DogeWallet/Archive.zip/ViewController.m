//
//  ViewController.m
//  DogeWallet
//
//  Created by Dysprosium on 1/17/14.
//  Copyright (c) 2014 Adorapuff. All rights reserved.
//

#import "ViewController.h"
@interface ViewController ()

@end

@implementation ViewController


-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [APIKey resignFirstResponder];
    [amt resignFirstResponder];
    [lbl resignFirstResponder];
    [addr resignFirstResponder];

    return YES;
}
- (IBAction)bal:(id) sender{
    NSString *api=APIKey.text;
    NSString *url = [NSString stringWithFormat: @"https://dogeapi.com/wow/?api_key=%@&a=get_balance", api];
    NSString *imageUrlString = url;
    NSURL *URL = [NSURL URLWithString:imageUrlString];
    NSData *data = [NSData dataWithContentsOfURL:URL];
    NSString *string = [NSString stringWithUTF8String:[data bytes]];
    NSString *someText = [NSString stringWithFormat: @"%@ DogeCoins!", string];
    label.text = someText;}
- (IBAction)with:(id) sender{
    NSString *api=APIKey.text;
    NSString *amount=amt.text;
    NSString *address=addr.text;
    NSString *url = [NSString stringWithFormat: @"https://dogeapi.com/wow/?api_key=%@&a=withdraw&amount=%@&payment_address=%@",api, amount, address];
    NSString *imageUrlString = url;
    NSURL *URL = [NSURL URLWithString:imageUrlString];
    NSData *data = [NSData dataWithContentsOfURL:URL];
    NSString *string = [NSString stringWithUTF8String:[data bytes]];
    label.text = @"Sent!";}
- (IBAction)newa:(id) sender{
    NSString *api=APIKey.text;
    NSString *lb=lbl.text;
    NSString *url = [NSString stringWithFormat: @"https://www.dogeapi.com/wow/?api_key=%@&a=get_new_address&address_label=%@", api, lb];
    NSString *imageUrlString = url;
    NSURL *URL = [NSURL URLWithString:imageUrlString];
    NSData *data = [NSData dataWithContentsOfURL:URL];
    NSString *string = [NSString stringWithUTF8String:[data bytes]];
    label.text = string;}
- (IBAction)my:(id) sender{
    NSString *api=APIKey.text;
    NSString *url = [NSString stringWithFormat: @"https://dogeapi.com/wow/?api_key=%@&a=get_my_addresses", api];
    NSString *imageUrlString = url;
    NSURL *URL = [NSURL URLWithString:imageUrlString];
    NSData *data = [NSData dataWithContentsOfURL:URL];
    NSString *string = [NSString stringWithUTF8String:[data bytes]];
    label.text = string;}
- (IBAction)diff:(id) sender{
    NSString *imageUrlString = @"https://dogeapi.com/wow/?a=get_difficulty";
    NSURL *URL = [NSURL URLWithString:imageUrlString];
    NSData *data = [NSData dataWithContentsOfURL:URL];
    NSString *string = [NSString stringWithUTF8String:[data bytes]];
    label.text = string;
}
- (IBAction)block:(id) sender{
    NSString *imageUrlString = @"https://dogeapi.com/wow/?a=get_current_block";
    NSURL *URL = [NSURL URLWithString:imageUrlString];
    NSData *data = [NSData dataWithContentsOfURL:URL];
    NSString *string = [NSString stringWithUTF8String:[data bytes]];
    label.text = string;
}

- (void)viewDidLoad
{
    APIKey.delegate = self;
    amt.delegate = self;
    lbl.delegate = self;
    addr.delegate = self;
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
